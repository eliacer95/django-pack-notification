from django.apps import AppConfig


class DjangoPackNotificationConfig(AppConfig):
    name = 'django_notification.django_pack_notification'
